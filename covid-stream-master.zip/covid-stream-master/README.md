# covid-stream
A streamming system for covid patients
